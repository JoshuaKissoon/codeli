-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 07, 2015 at 11:58 PM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `codeli`
--

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE IF NOT EXISTS `country` (
  `code` char(2) NOT NULL,
  `name` varchar(80) NOT NULL,
  `iso3_code` char(3) DEFAULT NULL,
  `numcode` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`code`, `name`, `iso3_code`, `numcode`) VALUES
('AD', 'Andorra', 'AND', 20),
('AE', 'United Arab Emirates', 'ARE', 784),
('AF', 'Afghanistan', 'AFG', 4),
('AG', 'Antigua and Barbuda', 'ATG', 28),
('AI', 'Anguilla', 'AIA', 660),
('AL', 'Albania', 'ALB', 8),
('AM', 'Armenia', 'ARM', 51),
('AN', 'Netherlands Antilles', 'ANT', 530),
('AO', 'Angola', 'AGO', 24),
('AQ', 'Antarctica', NULL, NULL),
('AR', 'Argentina', 'ARG', 32),
('AS', 'American Samoa', 'ASM', 16),
('AT', 'Austria', 'AUT', 40),
('AU', 'Australia', 'AUS', 36),
('AW', 'Aruba', 'ABW', 533),
('AZ', 'Azerbaijan', 'AZE', 31),
('BA', 'Bosnia and Herzegovina', 'BIH', 70),
('BB', 'Barbados', 'BRB', 52),
('BD', 'Bangladesh', 'BGD', 50),
('BE', 'Belgium', 'BEL', 56),
('BF', 'Burkina Faso', 'BFA', 854),
('BG', 'Bulgaria', 'BGR', 100),
('BH', 'Bahrain', 'BHR', 48),
('BI', 'Burundi', 'BDI', 108),
('BJ', 'Benin', 'BEN', 204),
('BM', 'Bermuda', 'BMU', 60),
('BN', 'Brunei Darussalam', 'BRN', 96),
('BO', 'Bolivia', 'BOL', 68),
('BR', 'Brazil', 'BRA', 76),
('BS', 'Bahamas', 'BHS', 44),
('BT', 'Bhutan', 'BTN', 64),
('BV', 'Bouvet Island', NULL, NULL),
('BW', 'Botswana', 'BWA', 72),
('BY', 'Belarus', 'BLR', 112),
('BZ', 'Belize', 'BLZ', 84),
('CA', 'Canada', 'CAN', 124),
('CC', 'Cocos (Keeling) Islands', NULL, NULL),
('CD', 'Congo, the Democratic Republic of the', 'COD', 180),
('CF', 'Central African Republic', 'CAF', 140),
('CG', 'Congo', 'COG', 178),
('CH', 'Switzerland', 'CHE', 756),
('CI', 'Cote D''Ivoire', 'CIV', 384),
('CK', 'Cook Islands', 'COK', 184),
('CL', 'Chile', 'CHL', 152),
('CM', 'Cameroon', 'CMR', 120),
('CN', 'China', 'CHN', 156),
('CO', 'Colombia', 'COL', 170),
('CR', 'Costa Rica', 'CRI', 188),
('CS', 'Serbia and Montenegro', NULL, NULL),
('CU', 'Cuba', 'CUB', 192),
('CV', 'Cape Verde', 'CPV', 132),
('CX', 'Christmas Island', NULL, NULL),
('CY', 'Cyprus', 'CYP', 196),
('CZ', 'Czech Republic', 'CZE', 203),
('DE', 'Germany', 'DEU', 276),
('DJ', 'Djibouti', 'DJI', 262),
('DK', 'Denmark', 'DNK', 208),
('DM', 'Dominica', 'DMA', 212),
('DO', 'Dominican Republic', 'DOM', 214),
('DZ', 'Algeria', 'DZA', 12),
('EC', 'Ecuador', 'ECU', 218),
('EE', 'Estonia', 'EST', 233),
('EG', 'Egypt', 'EGY', 818),
('EH', 'Western Sahara', 'ESH', 732),
('ER', 'Eritrea', 'ERI', 232),
('ES', 'Spain', 'ESP', 724),
('ET', 'Ethiopia', 'ETH', 231),
('FI', 'Finland', 'FIN', 246),
('FJ', 'Fiji', 'FJI', 242),
('FK', 'Falkland Islands (Malvinas)', 'FLK', 238),
('FM', 'Micronesia, Federated States of', 'FSM', 583),
('FO', 'Faroe Islands', 'FRO', 234),
('FR', 'France', 'FRA', 250),
('GA', 'Gabon', 'GAB', 266),
('GB', 'United Kingdom', 'GBR', 826),
('GD', 'Grenada', 'GRD', 308),
('GE', 'Georgia', 'GEO', 268),
('GF', 'French Guiana', 'GUF', 254),
('GH', 'Ghana', 'GHA', 288),
('GI', 'Gibraltar', 'GIB', 292),
('GL', 'Greenland', 'GRL', 304),
('GM', 'Gambia', 'GMB', 270),
('GN', 'Guinea', 'GIN', 324),
('GP', 'Guadeloupe', 'GLP', 312),
('GQ', 'Equatorial Guinea', 'GNQ', 226),
('GR', 'Greece', 'GRC', 300),
('GS', 'South Georgia and the South Sandwich Islands', NULL, NULL),
('GT', 'Guatemala', 'GTM', 320),
('GU', 'Guam', 'GUM', 316),
('GW', 'Guinea-Bissau', 'GNB', 624),
('GY', 'Guyana', 'GUY', 328),
('HK', 'Hong Kong', 'HKG', 344),
('HM', 'Heard Island and Mcdonald Islands', NULL, NULL),
('HN', 'Honduras', 'HND', 340),
('HR', 'Croatia', 'HRV', 191),
('HT', 'Haiti', 'HTI', 332),
('HU', 'Hungary', 'HUN', 348),
('ID', 'Indonesia', 'IDN', 360),
('IE', 'Ireland', 'IRL', 372),
('IL', 'Israel', 'ISR', 376),
('IN', 'India', 'IND', 356),
('IO', 'British Indian Ocean Territory', NULL, NULL),
('IQ', 'Iraq', 'IRQ', 368),
('IR', 'Iran, Islamic Republic of', 'IRN', 364),
('IS', 'Iceland', 'ISL', 352),
('IT', 'Italy', 'ITA', 380),
('JM', 'Jamaica', 'JAM', 388),
('JO', 'Jordan', 'JOR', 400),
('JP', 'Japan', 'JPN', 392),
('KE', 'Kenya', 'KEN', 404),
('KG', 'Kyrgyzstan', 'KGZ', 417),
('KH', 'Cambodia', 'KHM', 116),
('KI', 'Kiribati', 'KIR', 296),
('KM', 'Comoros', 'COM', 174),
('KN', 'Saint Kitts and Nevis', 'KNA', 659),
('KP', 'Korea, Democratic People''s Republic of', 'PRK', 408),
('KR', 'Korea, Republic of', 'KOR', 410),
('KW', 'Kuwait', 'KWT', 414),
('KY', 'Cayman Islands', 'CYM', 136),
('KZ', 'Kazakhstan', 'KAZ', 398),
('LA', 'Lao People''s Democratic Republic', 'LAO', 418),
('LB', 'Lebanon', 'LBN', 422),
('LC', 'Saint Lucia', 'LCA', 662),
('LI', 'Liechtenstein', 'LIE', 438),
('LK', 'Sri Lanka', 'LKA', 144),
('LR', 'Liberia', 'LBR', 430),
('LS', 'Lesotho', 'LSO', 426),
('LT', 'Lithuania', 'LTU', 440),
('LU', 'Luxembourg', 'LUX', 442),
('LV', 'Latvia', 'LVA', 428),
('LY', 'Libyan Arab Jamahiriya', 'LBY', 434),
('MA', 'Morocco', 'MAR', 504),
('MC', 'Monaco', 'MCO', 492),
('MD', 'Moldova, Republic of', 'MDA', 498),
('MG', 'Madagascar', 'MDG', 450),
('MH', 'Marshall Islands', 'MHL', 584),
('MK', 'Macedonia, the Former Yugoslav Republic of', 'MKD', 807),
('ML', 'Mali', 'MLI', 466),
('MM', 'Myanmar', 'MMR', 104),
('MN', 'Mongolia', 'MNG', 496),
('MO', 'Macao', 'MAC', 446),
('MP', 'Northern Mariana Islands', 'MNP', 580),
('MQ', 'Martinique', 'MTQ', 474),
('MR', 'Mauritania', 'MRT', 478),
('MS', 'Montserrat', 'MSR', 500),
('MT', 'Malta', 'MLT', 470),
('MU', 'Mauritius', 'MUS', 480),
('MV', 'Maldives', 'MDV', 462),
('MW', 'Malawi', 'MWI', 454),
('MX', 'Mexico', 'MEX', 484),
('MY', 'Malaysia', 'MYS', 458),
('MZ', 'Mozambique', 'MOZ', 508),
('NA', 'Namibia', 'NAM', 516),
('NC', 'New Caledonia', 'NCL', 540),
('NE', 'Niger', 'NER', 562),
('NF', 'Norfolk Island', 'NFK', 574),
('NG', 'Nigeria', 'NGA', 566),
('NI', 'Nicaragua', 'NIC', 558),
('NL', 'Netherlands', 'NLD', 528),
('NO', 'Norway', 'NOR', 578),
('NP', 'Nepal', 'NPL', 524),
('NR', 'Nauru', 'NRU', 520),
('NU', 'Niue', 'NIU', 570),
('NZ', 'New Zealand', 'NZL', 554),
('OM', 'Oman', 'OMN', 512),
('PA', 'Panama', 'PAN', 591),
('PE', 'Peru', 'PER', 604),
('PF', 'French Polynesia', 'PYF', 258),
('PG', 'Papua New Guinea', 'PNG', 598),
('PH', 'Philippines', 'PHL', 608),
('PK', 'Pakistan', 'PAK', 586),
('PL', 'Poland', 'POL', 616),
('PM', 'Saint Pierre and Miquelon', 'SPM', 666),
('PN', 'Pitcairn', 'PCN', 612),
('PR', 'Puerto Rico', 'PRI', 630),
('PS', 'Palestinian Territory, Occupied', NULL, NULL),
('PT', 'Portugal', 'PRT', 620),
('PW', 'Palau', 'PLW', 585),
('PY', 'Paraguay', 'PRY', 600),
('QA', 'Qatar', 'QAT', 634),
('RE', 'Reunion', 'REU', 638),
('RO', 'Romania', 'ROM', 642),
('RU', 'Russian Federation', 'RUS', 643),
('RW', 'Rwanda', 'RWA', 646),
('SA', 'Saudi Arabia', 'SAU', 682),
('SB', 'Solomon Islands', 'SLB', 90),
('SC', 'Seychelles', 'SYC', 690),
('SD', 'Sudan', 'SDN', 736),
('SE', 'Sweden', 'SWE', 752),
('SG', 'Singapore', 'SGP', 702),
('SH', 'Saint Helena', 'SHN', 654),
('SI', 'Slovenia', 'SVN', 705),
('SJ', 'Svalbard and Jan Mayen', 'SJM', 744),
('SK', 'Slovakia', 'SVK', 703),
('SL', 'Sierra Leone', 'SLE', 694),
('SM', 'San Marino', 'SMR', 674),
('SN', 'Senegal', 'SEN', 686),
('SO', 'Somalia', 'SOM', 706),
('SR', 'Suriname', 'SUR', 740),
('ST', 'Sao Tome and Principe', 'STP', 678),
('SV', 'El Salvador', 'SLV', 222),
('SY', 'Syrian Arab Republic', 'SYR', 760),
('SZ', 'Swaziland', 'SWZ', 748),
('TC', 'Turks and Caicos Islands', 'TCA', 796),
('TD', 'Chad', 'TCD', 148),
('TF', 'French Southern Territories', NULL, NULL),
('TG', 'Togo', 'TGO', 768),
('TH', 'Thailand', 'THA', 764),
('TJ', 'Tajikistan', 'TJK', 762),
('TK', 'Tokelau', 'TKL', 772),
('TL', 'Timor-Leste', NULL, NULL),
('TM', 'Turkmenistan', 'TKM', 795),
('TN', 'Tunisia', 'TUN', 788),
('TO', 'Tonga', 'TON', 776),
('TR', 'Turkey', 'TUR', 792),
('TT', 'Trinidad and Tobago', 'TTO', 780),
('TV', 'Tuvalu', 'TUV', 798),
('TW', 'Taiwan, Province of China', 'TWN', 158),
('TZ', 'Tanzania, United Republic of', 'TZA', 834),
('UA', 'Ukraine', 'UKR', 804),
('UG', 'Uganda', 'UGA', 800),
('UM', 'United States Minor Outlying Islands', NULL, NULL),
('US', 'United States', 'USA', 840),
('UY', 'Uruguay', 'URY', 858),
('UZ', 'Uzbekistan', 'UZB', 860),
('VA', 'Holy See (Vatican City State)', 'VAT', 336),
('VC', 'Saint Vincent and the Grenadines', 'VCT', 670),
('VE', 'Venezuela', 'VEN', 862),
('VG', 'Virgin Islands, British', 'VGB', 92),
('VI', 'Virgin Islands, U.s.', 'VIR', 850),
('VN', 'Viet Nam', 'VNM', 704),
('VU', 'Vanuatu', 'VUT', 548),
('WF', 'Wallis and Futuna', 'WLF', 876),
('WS', 'Samoa', 'WSM', 882),
('YE', 'Yemen', 'YEM', 887),
('YT', 'Mayotte', NULL, NULL),
('ZA', 'South Africa', 'ZAF', 710),
('ZM', 'Zambia', 'ZMB', 894),
('ZW', 'Zimbabwe', 'ZWE', 716);

-- --------------------------------------------------------

--
-- Table structure for table `day_of_week`
--

CREATE TABLE IF NOT EXISTS `day_of_week` (
  `did` int(11) NOT NULL AUTO_INCREMENT,
  `day` varchar(20) NOT NULL,
  PRIMARY KEY (`did`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Days of the week' AUTO_INCREMENT=7 ;

--
-- Dumping data for table `day_of_week`
--

INSERT INTO `day_of_week` (`did`, `day`) VALUES
(0, 'Sunday'),
(1, 'Monday'),
(2, 'Tuesday'),
(3, 'Wednesday'),
(4, 'Thursday'),
(5, 'Friday'),
(6, 'Saturday');

-- --------------------------------------------------------

--
-- Table structure for table `module`
--

CREATE TABLE IF NOT EXISTS `module` (
  `guid` varchar(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `type` varchar(50) NOT NULL DEFAULT 'site',
  `status` tinyint(4) NOT NULL,
  `info` text,
  `last_updated_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `module`
--

INSERT INTO `module` (`guid`, `title`, `description`, `type`, `status`, `info`, `last_updated_ts`) VALUES
('user', 'User Management', 'Module that handles all User Management', 'site', 1, NULL, '2015-01-06 13:49:50');

-- --------------------------------------------------------

--
-- Table structure for table `permission`
--

CREATE TABLE IF NOT EXISTS `permission` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `permission` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`pid`),
  UNIQUE KEY `permission` (`permission`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Table with the different permissions a module have' AUTO_INCREMENT=5 ;

--
-- Dumping data for table `permission`
--

INSERT INTO `permission` (`pid`, `permission`, `title`, `description`) VALUES
(1, 'view_users', 'View Users', ''),
(2, 'add_user', 'Add User', ''),
(3, 'edit_user', 'Edit User', ''),
(4, 'delete_user', 'Delete User', '');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE IF NOT EXISTS `role` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(50) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`rid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Different roles a user can have' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`rid`, `role`, `description`) VALUES
(1, 'anonymous', 'A User that is not logged into the website'),
(2, 'authenticated', 'A user that is authenticated and logged into the website');

-- --------------------------------------------------------

--
-- Table structure for table `role_permission`
--

CREATE TABLE IF NOT EXISTS `role_permission` (
  `rpid` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  PRIMARY KEY (`rpid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Links roles to permissions' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `route`
--

CREATE TABLE IF NOT EXISTS `route` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `module` varchar(100) NOT NULL,
  `pid` int(11) DEFAULT NULL COMMENT 'The Permission Id',
  `callback` varchar(255) NOT NULL,
  `method` enum('GET','POST','DELETE','PUT') NOT NULL DEFAULT 'GET',
  PRIMARY KEY (`rid`),
  UNIQUE KEY `UNIQUE_URL_PER_MODULE_PER_METHOD` (`module`,`url`,`method`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Contains the different URLs handled by different modules' AUTO_INCREMENT=7 ;

--
-- Dumping data for table `route`
--

INSERT INTO `route` (`rid`, `url`, `module`, `pid`, `callback`, `method`) VALUES
(1, 'admin/user', 'user', 1, 'user_get_users', 'GET');

-- --------------------------------------------------------

--
-- Table structure for table `system_log`
--

CREATE TABLE IF NOT EXISTS `system_log` (
  `lid` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`lid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='stores system logs' AUTO_INCREMENT=285 ;

--
-- Dumping data for table `system_log`
--

INSERT INTO `system_log` (`lid`, `type`, `message`, `ts`) VALUES
(39, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 09:09:57'),
(40, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 09:09:57'),
(41, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 09:09:57'),
(42, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 09:10:15'),
(43, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 09:10:15'),
(44, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 09:10:15'),
(45, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 09:11:16'),
(46, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 09:11:16'),
(47, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 09:11:16'),
(48, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 09:11:26'),
(49, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 09:11:26'),
(50, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 09:11:26'),
(51, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 09:13:43'),
(52, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 09:13:43'),
(53, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 09:13:43'),
(54, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 09:14:07'),
(55, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 09:14:07'),
(56, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 09:14:07'),
(57, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 10:16:03'),
(58, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 10:16:03'),
(59, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 10:16:03'),
(60, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 10:18:05'),
(61, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 10:18:05'),
(62, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 10:18:05'),
(63, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 10:51:11'),
(64, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 10:51:11'),
(65, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 10:51:11'),
(66, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 10:59:31'),
(67, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 10:59:31'),
(68, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 10:59:31'),
(69, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:02:18'),
(70, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:02:18'),
(71, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:02:18'),
(72, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:05:27'),
(73, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:05:27'),
(74, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:05:27'),
(75, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:06:16'),
(76, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:06:16'),
(77, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:06:16'),
(78, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:06:36'),
(79, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:06:36'),
(80, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:06:36'),
(81, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:07:29'),
(82, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:07:29'),
(83, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:07:29'),
(84, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:09:19'),
(85, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:09:19'),
(86, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:09:19'),
(87, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:09:47'),
(88, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:09:47'),
(89, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:09:47'),
(90, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:09:51'),
(91, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:09:51'),
(92, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:09:51'),
(93, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:12:14'),
(94, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:12:14'),
(95, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:12:14'),
(96, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:12:15'),
(97, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:12:15'),
(98, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:12:15'),
(99, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:12:16'),
(100, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:12:16'),
(101, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:12:16'),
(102, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:12:17'),
(103, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:12:17'),
(104, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:12:17'),
(105, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:12:19'),
(106, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:12:19'),
(107, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:12:19'),
(108, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:12:20'),
(109, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:12:20'),
(110, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:12:20'),
(111, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:12:21'),
(112, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:12:21'),
(113, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:12:21'),
(114, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:12:22'),
(115, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:12:22'),
(116, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:12:22'),
(117, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:31'),
(118, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:31'),
(119, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:31'),
(120, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:32'),
(121, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:32'),
(122, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:32'),
(123, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:33'),
(124, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:33'),
(125, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:33'),
(126, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:34'),
(127, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:34'),
(128, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:34'),
(129, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:35'),
(130, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:35'),
(131, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:35'),
(132, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:36'),
(133, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:36'),
(134, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:36'),
(135, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:37'),
(136, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:37'),
(137, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:37'),
(138, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:38'),
(139, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:38'),
(140, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:38'),
(141, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:39'),
(142, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:39'),
(143, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:39'),
(144, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:40'),
(145, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:40'),
(146, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:13:40'),
(147, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:03'),
(148, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:03'),
(149, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:03'),
(150, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:04'),
(151, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:04'),
(152, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:04'),
(153, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:05'),
(154, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:05'),
(155, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:05'),
(156, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:06'),
(157, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:06'),
(158, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:06'),
(159, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:07'),
(160, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:07'),
(161, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:07'),
(162, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:08'),
(163, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:08'),
(164, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:08'),
(165, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:09'),
(166, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:09'),
(167, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:09'),
(168, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:10'),
(169, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:10'),
(170, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:10'),
(171, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:11'),
(172, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:11'),
(173, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:11'),
(174, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:12'),
(175, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:12'),
(176, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:12'),
(177, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:54'),
(178, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:54'),
(179, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:54'),
(180, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:55'),
(181, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:55'),
(182, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:55'),
(183, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:56'),
(184, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:56'),
(185, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:56'),
(186, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:57'),
(187, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:57'),
(188, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:57'),
(189, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:58'),
(190, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:58'),
(191, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:58'),
(192, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:59'),
(193, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:59'),
(194, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:14:59'),
(195, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:15:00'),
(196, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:15:00'),
(197, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:15:00'),
(198, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:15:02'),
(199, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:15:02'),
(200, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:15:02'),
(201, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:15:03'),
(202, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:15:03'),
(203, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:15:03'),
(204, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:15:04'),
(205, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:15:04'),
(206, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:15:04'),
(207, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:16:33'),
(208, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:16:33'),
(209, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:16:33'),
(210, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:18:50'),
(211, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:18:50'),
(212, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:18:50'),
(213, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:20:00'),
(214, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:20:00'),
(215, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:20:00'),
(216, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:21:54'),
(217, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:21:54'),
(218, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:21:54'),
(219, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:24:12'),
(220, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:24:12'),
(221, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:24:12'),
(222, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:24:25'),
(223, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:24:25'),
(224, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:24:25'),
(225, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:30:46'),
(226, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:30:46'),
(227, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:30:46'),
(228, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:35:08'),
(229, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:35:08'),
(230, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:35:08'),
(231, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:35:23'),
(232, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:35:23'),
(233, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:35:23'),
(234, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:36:11'),
(235, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:36:12'),
(236, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:36:12'),
(237, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:36:35'),
(238, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:36:35'),
(239, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:36:35'),
(240, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:36:47'),
(241, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:36:47'),
(242, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:36:47'),
(243, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:37:13'),
(244, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:37:13'),
(245, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:37:13'),
(246, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:37:57'),
(247, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:37:57'),
(248, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 12:37:57'),
(249, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:28:36'),
(250, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:28:36'),
(251, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:28:36'),
(252, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:29:23'),
(253, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:29:23'),
(254, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:29:23'),
(255, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:30:05'),
(256, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:30:05'),
(257, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:30:05'),
(258, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:30:19'),
(259, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:30:19'),
(260, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:30:19'),
(261, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:30:26'),
(262, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:30:26'),
(263, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:30:26'),
(264, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:38:02'),
(265, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:38:02'),
(266, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:38:02'),
(267, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:38:20'),
(268, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:38:20'),
(269, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:38:20'),
(270, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:39:29'),
(271, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:39:29'),
(272, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:39:29'),
(273, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:39:49'),
(274, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:39:49'),
(275, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:39:49'),
(276, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:40:11'),
(277, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:40:11'),
(278, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:40:11'),
(279, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:40:21'),
(280, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:40:21'),
(281, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:40:21'),
(282, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:40:58'),
(283, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:40:58'),
(284, 'mysql', 'Error: Unknown column ''name'' in ''where clause'' Last Query: SELECT type FROM module WHERE name = ''user''', '2015-01-07 13:40:58');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(100) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `other_name` varchar(50) NOT NULL,
  `dob` date DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '5',
  `date_joined` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='users table' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `email`, `password`, `first_name`, `last_name`, `other_name`, `dob`, `status`, `date_joined`) VALUES
(1, 'admin@jsmart.com', '7d88299fe167f0e86198a0e8ac8adc483dfeaf29', '', '', '', NULL, 5, '2014-01-07 16:10:46');

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE IF NOT EXISTS `user_role` (
  `urid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT 'User ID',
  `rid` int(11) NOT NULL COMMENT 'Role Assigned to this user',
  PRIMARY KEY (`urid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Table that shows roles assigned to different admin' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user_session`
--

CREATE TABLE IF NOT EXISTS `user_session` (
  `usid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `sid` varchar(255) NOT NULL,
  `ipaddress` varchar(34) NOT NULL,
  `create_ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `data` text NOT NULL COMMENT 'Stores all of the data that was available in this session',
  PRIMARY KEY (`usid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Stores the users sessions' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user_status`
--

CREATE TABLE IF NOT EXISTS `user_status` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(50) NOT NULL,
  `status_description` varchar(200) NOT NULL,
  `user_allowed` int(11) NOT NULL COMMENT 'Is the user allowed to access the website with a status like this? Either 0 for no or 1 for yes',
  `error_msg` varchar(255) NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `user_status`
--

INSERT INTO `user_status` (`sid`, `status`, `status_description`, `user_allowed`, `error_msg`) VALUES
(1, 'Active', 'A User that is Currently an active wink user', 1, ''),
(2, 'Blocked', 'A User blocked various reasons', 0, 'Sorry, your account have been blocked.'),
(3, 'Account Disabled', 'A User who disabled his/her account for some reason', 0, 'You account have been disabled, for further information please contact the website administrator'),
(4, 'Banned', 'A user that has been banned from the website', 0, 'Sorry you have been banned from this website. For further information please contact the site administrator'),
(5, 'Awaiting Email Verification', 'When the email is sent to a user to confirm his/her account, until the account if confirmed, this will be the account status', 0, 'Please verify your email address before logging in.');

-- --------------------------------------------------------

--
-- Table structure for table `variable`
--

CREATE TABLE IF NOT EXISTS `variable` (
  `vid` varchar(50) NOT NULL,
  `value` text NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`vid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='site variables';

--
-- Dumping data for table `variable`
--

INSERT INTO `variable` (`vid`, `value`, `ts`) VALUES
('session_lifetime', '1209600', '2013-05-04 05:35:34'),
('sitename', 'Codeli', '2012-12-20 17:46:51'),
('site_email', 'admin@jsmart.com', '2014-01-23 09:09:46'),
('site_sender_email', 'noreply@jsmart.com', '2014-01-23 09:09:46');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
