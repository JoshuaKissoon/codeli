-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 10, 2015 at 05:44 PM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `codeli`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_log`
--

CREATE TABLE IF NOT EXISTS `activity_log` (
  `alid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT 'Which User',
  `alot` varchar(255) NOT NULL COMMENT 'Activity log Object',
  `aloid` int(11) NOT NULL COMMENT 'What object is the action performed on',
  `alaid` int(11) NOT NULL COMMENT 'what action was performed',
  `message` varchar(255) NOT NULL,
  `preObject` text NOT NULL,
  `postObject` text NOT NULL,
  `data` text NOT NULL,
  `createdTimestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`alid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='A log of all activities in the system' AUTO_INCREMENT=769334 ;

-- --------------------------------------------------------

--
-- Table structure for table `activity_log_action`
--

CREATE TABLE IF NOT EXISTS `activity_log_action` (
  `alaid` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`alaid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Different user actions that are logged' AUTO_INCREMENT=11 ;

--
-- Dumping data for table `activity_log_action`
--

INSERT INTO `activity_log_action` (`alaid`, `title`, `description`) VALUES
(1, 'Insert', '0'),
(2, 'Update', '0'),
(3, 'Delete', ''),
(4, 'View', ''),
(5, 'Login', ''),
(6, 'Logout', ''),
(7, 'Computation', ''),
(8, 'Activate', ''),
(9, 'Cancel', ''),
(10, 'Review', '');

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE IF NOT EXISTS `country` (
  `code` char(2) NOT NULL,
  `name` varchar(80) NOT NULL,
  `iso3_code` char(3) DEFAULT NULL,
  `numcode` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`code`, `name`, `iso3_code`, `numcode`) VALUES
('AD', 'Andorra', 'AND', 20),
('AE', 'United Arab Emirates', 'ARE', 784),
('AF', 'Afghanistan', 'AFG', 4),
('AG', 'Antigua and Barbuda', 'ATG', 28),
('AI', 'Anguilla', 'AIA', 660),
('AL', 'Albania', 'ALB', 8),
('AM', 'Armenia', 'ARM', 51),
('AN', 'Netherlands Antilles', 'ANT', 530),
('AO', 'Angola', 'AGO', 24),
('AQ', 'Antarctica', NULL, NULL),
('AR', 'Argentina', 'ARG', 32),
('AS', 'American Samoa', 'ASM', 16),
('AT', 'Austria', 'AUT', 40),
('AU', 'Australia', 'AUS', 36),
('AW', 'Aruba', 'ABW', 533),
('AZ', 'Azerbaijan', 'AZE', 31),
('BA', 'Bosnia and Herzegovina', 'BIH', 70),
('BB', 'Barbados', 'BRB', 52),
('BD', 'Bangladesh', 'BGD', 50),
('BE', 'Belgium', 'BEL', 56),
('BF', 'Burkina Faso', 'BFA', 854),
('BG', 'Bulgaria', 'BGR', 100),
('BH', 'Bahrain', 'BHR', 48),
('BI', 'Burundi', 'BDI', 108),
('BJ', 'Benin', 'BEN', 204),
('BM', 'Bermuda', 'BMU', 60),
('BN', 'Brunei Darussalam', 'BRN', 96),
('BO', 'Bolivia', 'BOL', 68),
('BR', 'Brazil', 'BRA', 76),
('BS', 'Bahamas', 'BHS', 44),
('BT', 'Bhutan', 'BTN', 64),
('BV', 'Bouvet Island', NULL, NULL),
('BW', 'Botswana', 'BWA', 72),
('BY', 'Belarus', 'BLR', 112),
('BZ', 'Belize', 'BLZ', 84),
('CA', 'Canada', 'CAN', 124),
('CC', 'Cocos (Keeling) Islands', NULL, NULL),
('CD', 'Congo, the Democratic Republic of the', 'COD', 180),
('CF', 'Central African Republic', 'CAF', 140),
('CG', 'Congo', 'COG', 178),
('CH', 'Switzerland', 'CHE', 756),
('CI', 'Cote D''Ivoire', 'CIV', 384),
('CK', 'Cook Islands', 'COK', 184),
('CL', 'Chile', 'CHL', 152),
('CM', 'Cameroon', 'CMR', 120),
('CN', 'China', 'CHN', 156),
('CO', 'Colombia', 'COL', 170),
('CR', 'Costa Rica', 'CRI', 188),
('CS', 'Serbia and Montenegro', NULL, NULL),
('CU', 'Cuba', 'CUB', 192),
('CV', 'Cape Verde', 'CPV', 132),
('CX', 'Christmas Island', NULL, NULL),
('CY', 'Cyprus', 'CYP', 196),
('CZ', 'Czech Republic', 'CZE', 203),
('DE', 'Germany', 'DEU', 276),
('DJ', 'Djibouti', 'DJI', 262),
('DK', 'Denmark', 'DNK', 208),
('DM', 'Dominica', 'DMA', 212),
('DO', 'Dominican Republic', 'DOM', 214),
('DZ', 'Algeria', 'DZA', 12),
('EC', 'Ecuador', 'ECU', 218),
('EE', 'Estonia', 'EST', 233),
('EG', 'Egypt', 'EGY', 818),
('EH', 'Western Sahara', 'ESH', 732),
('ER', 'Eritrea', 'ERI', 232),
('ES', 'Spain', 'ESP', 724),
('ET', 'Ethiopia', 'ETH', 231),
('FI', 'Finland', 'FIN', 246),
('FJ', 'Fiji', 'FJI', 242),
('FK', 'Falkland Islands (Malvinas)', 'FLK', 238),
('FM', 'Micronesia, Federated States of', 'FSM', 583),
('FO', 'Faroe Islands', 'FRO', 234),
('FR', 'France', 'FRA', 250),
('GA', 'Gabon', 'GAB', 266),
('GB', 'United Kingdom', 'GBR', 826),
('GD', 'Grenada', 'GRD', 308),
('GE', 'Georgia', 'GEO', 268),
('GF', 'French Guiana', 'GUF', 254),
('GH', 'Ghana', 'GHA', 288),
('GI', 'Gibraltar', 'GIB', 292),
('GL', 'Greenland', 'GRL', 304),
('GM', 'Gambia', 'GMB', 270),
('GN', 'Guinea', 'GIN', 324),
('GP', 'Guadeloupe', 'GLP', 312),
('GQ', 'Equatorial Guinea', 'GNQ', 226),
('GR', 'Greece', 'GRC', 300),
('GS', 'South Georgia and the South Sandwich Islands', NULL, NULL),
('GT', 'Guatemala', 'GTM', 320),
('GU', 'Guam', 'GUM', 316),
('GW', 'Guinea-Bissau', 'GNB', 624),
('GY', 'Guyana', 'GUY', 328),
('HK', 'Hong Kong', 'HKG', 344),
('HM', 'Heard Island and Mcdonald Islands', NULL, NULL),
('HN', 'Honduras', 'HND', 340),
('HR', 'Croatia', 'HRV', 191),
('HT', 'Haiti', 'HTI', 332),
('HU', 'Hungary', 'HUN', 348),
('ID', 'Indonesia', 'IDN', 360),
('IE', 'Ireland', 'IRL', 372),
('IL', 'Israel', 'ISR', 376),
('IN', 'India', 'IND', 356),
('IO', 'British Indian Ocean Territory', NULL, NULL),
('IQ', 'Iraq', 'IRQ', 368),
('IR', 'Iran, Islamic Republic of', 'IRN', 364),
('IS', 'Iceland', 'ISL', 352),
('IT', 'Italy', 'ITA', 380),
('JM', 'Jamaica', 'JAM', 388),
('JO', 'Jordan', 'JOR', 400),
('JP', 'Japan', 'JPN', 392),
('KE', 'Kenya', 'KEN', 404),
('KG', 'Kyrgyzstan', 'KGZ', 417),
('KH', 'Cambodia', 'KHM', 116),
('KI', 'Kiribati', 'KIR', 296),
('KM', 'Comoros', 'COM', 174),
('KN', 'Saint Kitts and Nevis', 'KNA', 659),
('KP', 'Korea, Democratic People''s Republic of', 'PRK', 408),
('KR', 'Korea, Republic of', 'KOR', 410),
('KW', 'Kuwait', 'KWT', 414),
('KY', 'Cayman Islands', 'CYM', 136),
('KZ', 'Kazakhstan', 'KAZ', 398),
('LA', 'Lao People''s Democratic Republic', 'LAO', 418),
('LB', 'Lebanon', 'LBN', 422),
('LC', 'Saint Lucia', 'LCA', 662),
('LI', 'Liechtenstein', 'LIE', 438),
('LK', 'Sri Lanka', 'LKA', 144),
('LR', 'Liberia', 'LBR', 430),
('LS', 'Lesotho', 'LSO', 426),
('LT', 'Lithuania', 'LTU', 440),
('LU', 'Luxembourg', 'LUX', 442),
('LV', 'Latvia', 'LVA', 428),
('LY', 'Libyan Arab Jamahiriya', 'LBY', 434),
('MA', 'Morocco', 'MAR', 504),
('MC', 'Monaco', 'MCO', 492),
('MD', 'Moldova, Republic of', 'MDA', 498),
('MG', 'Madagascar', 'MDG', 450),
('MH', 'Marshall Islands', 'MHL', 584),
('MK', 'Macedonia, the Former Yugoslav Republic of', 'MKD', 807),
('ML', 'Mali', 'MLI', 466),
('MM', 'Myanmar', 'MMR', 104),
('MN', 'Mongolia', 'MNG', 496),
('MO', 'Macao', 'MAC', 446),
('MP', 'Northern Mariana Islands', 'MNP', 580),
('MQ', 'Martinique', 'MTQ', 474),
('MR', 'Mauritania', 'MRT', 478),
('MS', 'Montserrat', 'MSR', 500),
('MT', 'Malta', 'MLT', 470),
('MU', 'Mauritius', 'MUS', 480),
('MV', 'Maldives', 'MDV', 462),
('MW', 'Malawi', 'MWI', 454),
('MX', 'Mexico', 'MEX', 484),
('MY', 'Malaysia', 'MYS', 458),
('MZ', 'Mozambique', 'MOZ', 508),
('NA', 'Namibia', 'NAM', 516),
('NC', 'New Caledonia', 'NCL', 540),
('NE', 'Niger', 'NER', 562),
('NF', 'Norfolk Island', 'NFK', 574),
('NG', 'Nigeria', 'NGA', 566),
('NI', 'Nicaragua', 'NIC', 558),
('NL', 'Netherlands', 'NLD', 528),
('NO', 'Norway', 'NOR', 578),
('NP', 'Nepal', 'NPL', 524),
('NR', 'Nauru', 'NRU', 520),
('NU', 'Niue', 'NIU', 570),
('NZ', 'New Zealand', 'NZL', 554),
('OM', 'Oman', 'OMN', 512),
('PA', 'Panama', 'PAN', 591),
('PE', 'Peru', 'PER', 604),
('PF', 'French Polynesia', 'PYF', 258),
('PG', 'Papua New Guinea', 'PNG', 598),
('PH', 'Philippines', 'PHL', 608),
('PK', 'Pakistan', 'PAK', 586),
('PL', 'Poland', 'POL', 616),
('PM', 'Saint Pierre and Miquelon', 'SPM', 666),
('PN', 'Pitcairn', 'PCN', 612),
('PR', 'Puerto Rico', 'PRI', 630),
('PS', 'Palestinian Territory, Occupied', NULL, NULL),
('PT', 'Portugal', 'PRT', 620),
('PW', 'Palau', 'PLW', 585),
('PY', 'Paraguay', 'PRY', 600),
('QA', 'Qatar', 'QAT', 634),
('RE', 'Reunion', 'REU', 638),
('RO', 'Romania', 'ROM', 642),
('RU', 'Russian Federation', 'RUS', 643),
('RW', 'Rwanda', 'RWA', 646),
('SA', 'Saudi Arabia', 'SAU', 682),
('SB', 'Solomon Islands', 'SLB', 90),
('SC', 'Seychelles', 'SYC', 690),
('SD', 'Sudan', 'SDN', 736),
('SE', 'Sweden', 'SWE', 752),
('SG', 'Singapore', 'SGP', 702),
('SH', 'Saint Helena', 'SHN', 654),
('SI', 'Slovenia', 'SVN', 705),
('SJ', 'Svalbard and Jan Mayen', 'SJM', 744),
('SK', 'Slovakia', 'SVK', 703),
('SL', 'Sierra Leone', 'SLE', 694),
('SM', 'San Marino', 'SMR', 674),
('SN', 'Senegal', 'SEN', 686),
('SO', 'Somalia', 'SOM', 706),
('SR', 'Suriname', 'SUR', 740),
('ST', 'Sao Tome and Principe', 'STP', 678),
('SV', 'El Salvador', 'SLV', 222),
('SY', 'Syrian Arab Republic', 'SYR', 760),
('SZ', 'Swaziland', 'SWZ', 748),
('TC', 'Turks and Caicos Islands', 'TCA', 796),
('TD', 'Chad', 'TCD', 148),
('TF', 'French Southern Territories', NULL, NULL),
('TG', 'Togo', 'TGO', 768),
('TH', 'Thailand', 'THA', 764),
('TJ', 'Tajikistan', 'TJK', 762),
('TK', 'Tokelau', 'TKL', 772),
('TL', 'Timor-Leste', NULL, NULL),
('TM', 'Turkmenistan', 'TKM', 795),
('TN', 'Tunisia', 'TUN', 788),
('TO', 'Tonga', 'TON', 776),
('TR', 'Turkey', 'TUR', 792),
('TT', 'Trinidad and Tobago', 'TTO', 780),
('TV', 'Tuvalu', 'TUV', 798),
('TW', 'Taiwan, Province of China', 'TWN', 158),
('TZ', 'Tanzania, United Republic of', 'TZA', 834),
('UA', 'Ukraine', 'UKR', 804),
('UG', 'Uganda', 'UGA', 800),
('UM', 'United States Minor Outlying Islands', NULL, NULL),
('US', 'United States', 'USA', 840),
('UY', 'Uruguay', 'URY', 858),
('UZ', 'Uzbekistan', 'UZB', 860),
('VA', 'Holy See (Vatican City State)', 'VAT', 336),
('VC', 'Saint Vincent and the Grenadines', 'VCT', 670),
('VE', 'Venezuela', 'VEN', 862),
('VG', 'Virgin Islands, British', 'VGB', 92),
('VI', 'Virgin Islands, U.s.', 'VIR', 850),
('VN', 'Viet Nam', 'VNM', 704),
('VU', 'Vanuatu', 'VUT', 548),
('WF', 'Wallis and Futuna', 'WLF', 876),
('WS', 'Samoa', 'WSM', 882),
('YE', 'Yemen', 'YEM', 887),
('YT', 'Mayotte', NULL, NULL),
('ZA', 'South Africa', 'ZAF', 710),
('ZM', 'Zambia', 'ZMB', 894),
('ZW', 'Zimbabwe', 'ZWE', 716);

-- --------------------------------------------------------

--
-- Table structure for table `day_of_week`
--

CREATE TABLE IF NOT EXISTS `day_of_week` (
  `did` int(11) NOT NULL AUTO_INCREMENT,
  `day` varchar(20) NOT NULL,
  PRIMARY KEY (`did`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Days of the week' AUTO_INCREMENT=8 ;

--
-- Dumping data for table `day_of_week`
--

INSERT INTO `day_of_week` (`did`, `day`) VALUES
(1, 'Sunday'),
(2, 'Monday'),
(3, 'Tuesday'),
(4, 'Wednesday'),
(5, 'Thursday'),
(6, 'Friday'),
(7, 'Saturday');

-- --------------------------------------------------------

--
-- Table structure for table `module`
--

CREATE TABLE IF NOT EXISTS `module` (
  `guid` varchar(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `type` varchar(50) NOT NULL DEFAULT 'site',
  `status` tinyint(4) NOT NULL,
  `info` text,
  `createdTimestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `module`
--

INSERT INTO `module` (`guid`, `title`, `description`, `type`, `status`, `info`, `createdTimestamp`) VALUES
('example', 'Example Module', 'A Simple module to demonstrate how to develop modules', 'site', 1, NULL, '2015-09-10 13:08:33'),
('user', 'User Management', 'Module that handles all User Management', 'system', 1, NULL, '2015-01-06 13:49:50');

-- --------------------------------------------------------

--
-- Table structure for table `module_dependency`
--

CREATE TABLE IF NOT EXISTS `module_dependency` (
  `mdid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Unique Module Dependency ID',
  `guid` varchar(255) NOT NULL COMMENT 'GUID of the main module',
  `dependencyGuid` varchar(255) NOT NULL COMMENT 'GUID of the module''s Dependency',
  PRIMARY KEY (`mdid`),
  UNIQUE KEY `ONE_MODULE_TO_ANOTHER_DEPENDENCY` (`guid`,`dependencyGuid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Table with a set of module dependencies' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `permission`
--

CREATE TABLE IF NOT EXISTS `permission` (
  `permission` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `module` varchar(255) NOT NULL,
  PRIMARY KEY (`permission`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Table with the different permissions a module have';

--
-- Dumping data for table `permission`
--

INSERT INTO `permission` (`permission`, `title`, `description`, `module`) VALUES
('add_user', 'Add User', '', ''),
('delete_user', 'Delete User', '', ''),
('edit_user', 'Edit User', '', ''),
('example_number_add', 'Example: Add', '', 'example'),
('example_number_delete', 'Example: Delete', '', 'example'),
('example_number_edit', 'Example: Edit', '', 'example'),
('example_number_view', 'Example: View', '', 'example'),
('rbac_add_role', 'RBAC: Add Role', '', 'user'),
('rbac_add_role_permission', 'RBAC: Add Role Permission', '', 'user'),
('rbac_edit_role', 'RBAC: Edit Role', '', 'user'),
('rbac_remove_role_permission', 'RBAC: Delete Role Permission', '', 'user'),
('rbac_view_permission', 'RBAC: View Permission', '', 'user'),
('rbac_view_role', 'RBAC: View Role', '', 'user'),
('user_add_role', 'User: Add User Role', '', 'user'),
('user_add_user', 'User: Add', '', 'user'),
('user_delete_user', 'User: Delete', '', 'user'),
('user_edit_role', 'User: Edit User Role', '', 'user'),
('user_edit_user', 'User: Edit', '', 'user'),
('user_view_role', 'User: View User Roles', '', 'user'),
('user_view_user', 'User: View', '', 'user'),
('view_users', 'View Users', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE IF NOT EXISTS `role` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`rid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Different roles a user can have' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`rid`, `title`, `description`) VALUES
(1, 'anonymous', 'A User that is not logged into the website'),
(2, 'authenticated', 'A user that is authenticated and logged into the website');

-- --------------------------------------------------------

--
-- Table structure for table `role_permission`
--

CREATE TABLE IF NOT EXISTS `role_permission` (
  `rpid` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(11) NOT NULL,
  `permission` varchar(255) NOT NULL,
  PRIMARY KEY (`rpid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Links roles to permissions' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `route`
--

CREATE TABLE IF NOT EXISTS `route` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `module` varchar(100) NOT NULL,
  `permission` varchar(255) DEFAULT NULL COMMENT 'The Permission Id',
  `callback` varchar(255) NOT NULL,
  `method` enum('GET','POST','DELETE','PUT') NOT NULL DEFAULT 'GET',
  PRIMARY KEY (`rid`),
  UNIQUE KEY `UNIQUE_URL_PER_MODULE_PER_METHOD` (`module`,`url`,`method`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Contains the different URLs handled by different modules' AUTO_INCREMENT=73 ;

--
-- Dumping data for table `route`
--

INSERT INTO `route` (`rid`, `url`, `module`, `permission`, `callback`, `method`) VALUES
(1, 'admin/user', 'user', '1', 'user_get_users', 'GET'),
(2, 'admin/user', 'user', 'user_add_user', 'user_add_user', 'PUT'),
(3, 'admin/user', 'user', 'user_edit_user', 'user_edit_user', 'POST'),
(4, 'admin/user/all', 'user', 'user_view_user', 'user_get_users', 'POST'),
(5, 'admin/user/%', 'user', 'user_view_user', 'user_get_user', 'GET'),
(6, 'admin/user/login', 'user', '', 'user_login_user', 'POST'),
(7, 'admin/user/session', 'user', '', 'user_get_session', 'GET'),
(8, 'admin/user/logout', 'user', '', 'user_logout_user', 'POST'),
(9, 'rbac/role', 'user', 'rbac_add_role', 'rbac_role_add', 'PUT'),
(10, 'rbac/role/%', 'user', 'rbac_view_role', 'rbac_role_view', 'GET'),
(11, 'rbac/role', 'user', 'rbac_edit_role', 'rbac_role_edit', 'POST'),
(12, 'rbac/role/all', 'user', 'rbac_view_role', 'rbac_role_view_all', 'POST'),
(13, 'rbac/permission/all', 'user', 'rbac_view_permission', 'rbac_get_permissions', 'GET'),
(14, 'rbac/role/permission', 'user', 'rbac_add_role_permission', 'rbac_role_add_permission', 'PUT'),
(15, 'rbac/role/permission', 'user', 'rbac_remove_role_permission', 'rbac_role_remove_permission', 'POST'),
(30, 'example/numbers', 'example', 'example_number_add', 'example_number_add', 'PUT'),
(31, 'example/numbers', 'example', '', 'example_numbers_view', 'POST'),
(32, 'example/numbers/%', 'example', '', 'example_number_view', 'GET'),
(34, 'example/numbers/%', 'example', 'example_number_delete', 'example_number_delete', 'DELETE'),
(71, 'example/numbers/%', 'example', 'example_number_edit', 'example_number_edit', 'POST');

-- --------------------------------------------------------

--
-- Table structure for table `system_log`
--

CREATE TABLE IF NOT EXISTS `system_log` (
  `lid` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`lid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='stores system logs' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `userid` varchar(255) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(100) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `otherName` varchar(50) NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '5',
  `date_joined` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='users table' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `userid`, `email`, `password`, `firstName`, `lastName`, `otherName`, `status`, `date_joined`) VALUES
(1, '', 'admin@jsmart.com', '7d88299fe167f0e86198a0e8ac8adc483dfeaf29', '', '', '', 5, '2014-01-07 16:10:46');

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE IF NOT EXISTS `user_role` (
  `urid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT 'User ID',
  `rid` int(11) NOT NULL COMMENT 'Role Assigned to this user',
  PRIMARY KEY (`urid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Table that shows roles assigned to different admin' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user_session`
--

CREATE TABLE IF NOT EXISTS `user_session` (
  `usid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `token` varchar(255) NOT NULL COMMENT 'The active session ID',
  `ipAddress` varchar(34) NOT NULL,
  `ussid` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'User session status',
  `data` text NOT NULL COMMENT 'Stores all of the data that was available in this session',
  `createdTimestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`usid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Stores the users sessions' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user_session_status`
--

CREATE TABLE IF NOT EXISTS `user_session_status` (
  `ussid` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`ussid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Different statuses of a user session' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `user_session_status`
--

INSERT INTO `user_session_status` (`ussid`, `title`, `description`) VALUES
(1, 'Active', 'An active session which can be used to access system data. '),
(2, 'Invalidated', 'A session invalidated for some reason');

-- --------------------------------------------------------

--
-- Table structure for table `user_status`
--

CREATE TABLE IF NOT EXISTS `user_status` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `isAllowed` int(11) NOT NULL COMMENT 'Is the user allowed to access the website with a status like this? Either 0 for no or 1 for yes',
  `error_msg` varchar(255) NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `user_status`
--

INSERT INTO `user_status` (`sid`, `title`, `description`, `isAllowed`, `error_msg`) VALUES
(1, 'Active', 'A User that is Currently an active wink user', 1, ''),
(2, 'Blocked', 'A User blocked various reasons', 0, 'Sorry, your account have been blocked.'),
(3, 'Account Disabled', 'A User who disabled his/her account for some reason', 0, 'You account have been disabled, for further information please contact the website administrator'),
(4, 'Banned', 'A user that has been banned from the website', 0, 'Sorry you have been banned from this website. For further information please contact the site administrator'),
(5, 'Awaiting Email Verification', 'When the email is sent to a user to confirm his/her account, until the account if confirmed, this will be the account status', 0, 'Please verify your email address before logging in.');

-- --------------------------------------------------------

--
-- Table structure for table `variable`
--

CREATE TABLE IF NOT EXISTS `variable` (
  `vid` varchar(50) NOT NULL,
  `value` text NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`vid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='site variables';

--
-- Dumping data for table `variable`
--

INSERT INTO `variable` (`vid`, `value`, `ts`) VALUES
('session_lifetime', '1209600', '2013-05-04 05:35:34'),
('sitename', 'Codeli', '2012-12-20 17:46:51'),
('site_email', 'admin@jsmart.com', '2014-01-23 09:09:46'),
('site_sender_email', 'noreply@jsmart.com', '2014-01-23 09:09:46');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
